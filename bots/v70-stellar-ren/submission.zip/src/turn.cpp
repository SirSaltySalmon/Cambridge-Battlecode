// What a champion does on its turn, in order.
#include "bot.h"
#include "seen.h"
#include "state.h"
#include "trace.h"
#include <exception>

void Bot::play_turn() {
    auto& me = bc::self();
    begin_trace();
    std::exception_ptr failure;
    const auto start_round = bc::round_number();
    try {
        play(me);
    } catch (...) {
        failure = std::current_exception();
        // A turn that ran out of fuel resumes next round at the same line, with vision lists a round old;
        // reading a unit that has since left sight throws. Play that round's turn again from scratch.
        // Costs nothing on normal turns: only a failed turn checks.
        if (bc::round_number() != start_round) {
            begin_trace();
            note(format("turn resumed after running out of fuel in round %u; replayed with fresh vision", start_round));
            failure = nullptr;
            try {
                play(me);
            } catch (...) {
                failure = std::current_exception();
            }
        }
    }
    // Like Python's finally: these run whether or not the turn failed, then the error goes on to main.
    try {
        remember_allies();
    } catch (const std::exception& error) {
        say(std::string("ally memory error: ") + error_text(error));
    }
    try {
        log_turn(me);
    } catch (const std::exception& error) {
        say(std::string("log error: ") + error_text(error));
    }
    try {
        build_fields();
    } catch (const std::exception& error) {
        say(std::string("field build error: ") + error_text(error));
    }
    if (failure) std::rethrow_exception(failure);
}

void Bot::play(const bc::champion& me) {
    channel_cut = false;
    if (!ready) setup();
    if (!priority_set) {
        me.set_priority(priority_of(me.champion_name()));
        priority_set = true;
    }
    if (me.is_alive()) observe();
    update_emblems();
    sync_decision(me);

    // Dead champions still get a turn to shop.
    if (!me.is_alive()) {
        buy_items(me);
        branch("dead.shop", "dead, buy from spawn shop");
        return;
    }
    update_carrier(me);

    // 1. Stay on a channel an enemy cannot hit. One step out is safe when it ends next turn.
    if (me.is_recalling() || me.is_submitting_gems() || me.is_teleporting()) {
        const std::string kind = me.is_recalling() ? "recall" : me.is_submitting_gems() ? "tribute" : "teleport";
        if (kind == "teleport") {
            branch("channel.teleport", "teleport cannot be cancelled, " + channel_left(me));
            return;
        }
        auto [threat, why] = channel_threat(me);
        if (!threat || !stop_channel(me)) {
            if (threat) why = "cancel rejected; " + why;
            branch("channel." + kind, why);
            return;
        }
        channel_cut = true;
        note("aborts " + kind + ": " + why);
    }

    // Placing a ward costs no move, attack or cast, so it is tried every turn; an unused one may go
    // into a key bush instead.
    if (!place_ward(me)) bush_ward(me);

    // 2. On spawn: buy, stay until healed (spawn heals at turn end), then head out.
    const auto position = me.position();
    if (seen::ally_spawn().is_set(position)) {
        tributed = false;
        buy_items(me);
        if (me.health() < me.max_health()) {
            branch("spawn.heal", "on ally spawn, not full, wait for heal");
            return;
        }
        if (win_tribute && mode != FIGHT) {
            if (me.gem_count() > 0)
                bank_gems(me, {}, "win");
            else
                branch("win.tribute.wait", "no gems to submit; hold on spawn");
            return;
        }
        if (!route.empty()) {
            branch("spawn.leave", "full hp, leave toward " + slot_text());
            move_towards_closest(spawn_board(slot % static_cast<int>(route.size())));
        } else {
            branch("spawn.stay", "full hp but no route");
        }
        return;
    }

    // 3. Recall when hurt and nothing can interrupt it; otherwise step out of reach first.
    if (me.health() < me.max_health() * RECALL_HEALTH) {
        const auto zone = threat_zone(seen::champions(Team::enemy), true);
        const std::string hurt = format("below %.0f%% health", RECALL_HEALTH * 100);
        if (!channel_cut && !zone.is_set(position)) {
            try {
                me.recall();
                trace::act("recall");
                branch("hurt.recall", hurt + ", tile not in threat");
                return;
            } catch (const bc::error& error) {
                note(std::string("recall rejected (") + error_text(error) + ")");
            }
        }
        const std::string why = channel_cut ? "channel just aborted, not recalling again this turn" : "stepping out of threat";
        branch("hurt.dodge", hurt + ", " + why);
        move_towards_closest(~zone);
        return;
    }

    // 4. The one champion collecting a cleared group stays on it unless something can hit it.
    if (!win_tribute) {
        ren_claim(me);
        share_loot(me);
        if (is_collector(me) && under_threat(me))
            note(format("collector of slot %d skipped, under threat", capture_slot));
        else if (is_collector(me) && collect(me))
            return;
    }

    // 5. Engaging outranks any tribute. The shared mode comes from the leader's vision, so enemies
    // in our own sight are scored here too. A carrier too hurt for the front line stays behind.
    const int gems = static_cast<int>(me.gem_count());
    if (gems > 0) tributed = false;
    // v70: Ren rushes his core build first; afterwards he is the team's carry.
    const bool ren = me.champion_name() == Champ::ren;
    const bool ren_rush = ren && emblem_count(me) < REN_CORE_EMBLEMS;
    int now_mode = mode;
    const auto& enemies = seen::champions(Team::enemy);
    if (!enemies.empty() && (now_mode == FARM || now_mode == TRIBUTE)) {
        const int personal = local_prev;
        now_mode = score_mode(position, personal);
        local_why = std::string("rescore shared ") + MODE_NAMES[mode] + " with personal " + MODE_NAMES[personal] + ": " + score_why;
        // A built Ren takes a fight his own score likes only with an ally beside him, not alone.
        if (ren && !ren_rush && now_mode == FIGHT) {
            bool backed = false;
            for (const auto& ally : seen::champions(Team::ally))
                if (ally != me && distance(position, ally.position()) <= REN_FIGHT_ALLY_RANGE) backed = true;
            if (!backed) {
                now_mode = mode;
                note(format("ren would fight but no ally within %d, keeps shared %s", REN_FIGHT_ALLY_RANGE, MODE_NAMES[mode]));
            }
        }
    }
    local_prev = now_mode;
    if (win_tribute && now_mode != FIGHT) {
        if (gems > 0)
            bank_gems(me, {}, "win");
        else
            branch("win.tribute.wait", "team can win; no gems to submit");
        return;
    }
    if (gems >= ESCORT_GEMS && me.health() < FRONT_HEALTH && (now_mode == FIGHT || now_mode == RETREAT)) {
        if (retreat(me)) {
            branch_name = "front." + branch_name;
            branch_why = "heavy bag, too hurt for the front; " + branch_why;
            return;
        }
    } else if (now_mode == FIGHT) {
        if (fight(me)) return;
        note("mode fight but no living enemy, fall through");
    }
    // 5b. A built Ren banks his capped bag before anything but a fight (a retreat counts as one): alone,
    // at the nearest altar, and then recalls to shop once the tribute is in (step 8).
    if (ren && !ren_rush && gems >= REN_BANK_GEMS && now_mode != RETREAT && bank_gems(me, {}, "ren.bank")) {
        branch_why = format("ren bag %d >= cap %d; ", gems, REN_BANK_GEMS) + branch_why;
        return;
    }

    // 6. A heavy bag goes to the altar with the team; everyone else escorts it there.
    const int mine = champ_id(me.champion_name()) + 1;
    if (carrier == mine && carry(me)) return;
    if (now_mode == TRIBUTE && carrier != mine) {
        if (escort(me)) return;
        note("tribute but escort declined, fall through");
    }

    // 7a. While rushing his build, Ren goes to shop at every emblem's worth of gold, before banking and
    // with his bag still carried: items come first.
    if (ren_rush && static_cast<int>(me.gold_count()) >= REN_RECALL_GOLD && recall_to_shop(me)) {
        branch_why = "ren rush: purse covers an emblem; " + branch_why;
        return;
    }

    // 7. Bank a full bag, or a smaller one while the target is still respawning.
    // A built Ren keeps his bag until it reaches his cap (step 5b), so he never banks here.
    const bool building = ren && !ren_rush;
    // A heavy bag goes alone to a solo altar; a locked one still works, as tributing breaks the lock.
    const bool idle = !route.empty() && wait_at(slot % static_cast<int>(route.size()), position) > 0;
    if (!building && gems >= ESCORT_GEMS && carrier != mine) {
        if (!solo_altars.empty() && bank_gems(me, solo_altars, "bank.solo")) return;
    } else if (!building && (gems >= GEM_BANK || (idle && gems >= IDLE_BANK)) && bank_gems(me)) {
        return;
    }

    // 8. Return to shop at the gold threshold; Ren goes at every emblem's worth, with his bag still carried.
    const int recall_gold = ren_rush ? REN_RECALL_GOLD : RECALL_GOLD;
    const bool ready_to_shop = ren_rush || (tributed && gems == 0);
    if (static_cast<int>(me.gold_count()) >= recall_gold) {
        if (!ready_to_shop) {
            note(std::string("purse at recall bar but shop gated (ren ") + (ren ? "True" : "False") + ", tributed "
                 + (tributed ? "True" : "False") + ", building " + (building ? "True" : "False") + ")");
        } else if (recall_to_shop(me)) {
            branch_why = "purse at recall bar; " + branch_why;
            return;
        } else {
            note("purse at recall bar but recall refused");
        }
    }

    // 9-10. Follow the mode; a quiet farm turn may walk over to an uncovered ward spot.
    if (now_mode == RETREAT && retreat(me)) return;
    if (now_mode == FARM && ward_detour(me, gems)) return;
    if (now_mode != FARM && now_mode != RETREAT) note(std::string("mode ") + MODE_NAMES[now_mode] + " reached farm fallback");
    farm(me);
}
